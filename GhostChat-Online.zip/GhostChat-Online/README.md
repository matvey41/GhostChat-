# GhostChat Online — ранняя версия

Эта версия добавляет аккаунты и один общий онлайн-чат на Supabase.

## Что нужно настроить
1. В Supabase открой **SQL Editor → New query**, вставь содержимое `supabase-setup.sql` и нажми **Run**.
2. В Supabase открой **Project Settings → API Keys** (или раздел API Keys).
3. Скопируй **Project URL** и **Publishable key**. Не используй и никому не отправляй `sb_secret_...`.
4. В `index.html` замени:
   - `ВСТАВЬ_PROJECT_URL` на свой Project URL;
   - `ВСТАВЬ_PUBLISHABLE_KEY` на свой Publishable key.
5. Загрузи обновлённый `index.html` в корень GitHub-репозитория, заменив старый файл.

## Важно
- Это пока **один общий чат**, не личные переписки.
- Publishable key можно использовать в браузере только вместе с включённой RLS и политиками. SQL выше включает RLS и ограничивает отправку сообщений вошедшими пользователями.
- Никогда не добавляй `sb_secret_...` в HTML/JavaScript.
- Для регистрации может понадобиться подтверждение электронной почты.
